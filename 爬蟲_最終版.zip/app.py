import streamlit as st
import asyncio
import os
import json
import time
import pandas as pd
from company_resume_scraper import ResumeScraper, ResumeScraperConfig

# 設置頁面配置
st.set_page_config(page_title="104履歷爬蟲工具", layout="wide")

# 標題與介紹
st.title("104人力銀行履歷爬蟲工具")
st.markdown("此工具僅供學習研究使用，請勿用於商業或非法用途，並遵守104相關使用條款及個人資料保護法")

# 側邊欄配置檔案管理
with st.sidebar:
    st.header("設定管理")
    
    # 檢查是否有已儲存的使用者資訊
    config_file = "user_config.json"
    saved_config = {}
    
    if os.path.exists(config_file):
        try:
            with open(config_file, "r", encoding="utf-8") as f:
                saved_config = json.load(f)
            st.success("找到已儲存的帳號資訊")
        except:
            st.warning("讀取儲存的帳號資訊時出錯")
    
    use_saved = False
    if saved_config.get("username"):
        use_saved = st.checkbox(f"使用已儲存的帳號 ({saved_config.get('username')})", value=True)

# 建立主頁面的輸入表單
with st.form("scraper_form"):
    col1, col2 = st.columns(2)
    
    with col1:
        if use_saved and saved_config.get("username") and saved_config.get("password"):
            username = st.text_input("104企業會員帳號", value=saved_config.get("username"))
            password = st.text_input("104企業會員密碼", value=saved_config.get("password"), type="password")
        else:
            username = st.text_input("104企業會員帳號")
            password = st.text_input("104企業會員密碼", type="password")
    
    with col2:
        keyword = st.text_input("搜索關鍵詞 (直接留空搜索全部)")
        page_limit = st.number_input("要爬取的頁數", min_value=1, value=1)
        
    save_account = st.checkbox("記住帳號密碼")
    
    col3, col4 = st.columns([1, 3])
    with col3:
        submitted = st.form_submit_button("開始爬取")

# 處理表單提交
if submitted:
    # 儲存帳號密碼（如選擇）
    if save_account:
        try:
            with open(config_file, "w", encoding="utf-8") as f:
                json.dump({"username": username, "password": password}, f)
            st.success("已儲存帳號資訊")
        except Exception as e:
            st.error(f"儲存帳號資訊失敗: {str(e)}")
    
    # 建立進度顯示區域
    progress_bar = st.progress(0)
    status_text = st.empty()
    result_area = st.empty()
    
    # 建立爬蟲配置
    status_text.info("正在初始化爬蟲設定...")
    
    config = ResumeScraperConfig(
        username=username,
        password=password,
        search_keyword=keyword,
        page_limit=int(page_limit)
    )
    
    # 定義用於更新進度的回調
    class ScraperCallback:
        def __init__(self, status_text, progress_bar):
            self.status_text = status_text
            self.progress_bar = progress_bar
            self.last_progress = 0
        
        def update(self, message, progress=None):
            self.status_text.info(message)
            if progress is not None:
                self.progress_bar.progress(progress)
                self.last_progress = progress
    
    # 建立回調物件
    callback = ScraperCallback(status_text, progress_bar)
    
    # 定義運行爬蟲的異步函數
    async def run_scraping():
        scraper = ResumeScraper(config)
        try:
            # 初始化瀏覽器
            callback.update("正在初始化瀏覽器...", 5)
            await scraper.initialize()
            
            # 登入
            callback.update("正在登入104網站...", 15)
            login_success = await scraper.login()
            if not login_success:
                callback.update("登入失敗，請檢查您的帳號和密碼", 0)
                return False
            
            callback.update("登入成功！", 30)
            
            # 搜尋
            if config.search_keyword:
                callback.update(f"正在搜尋關鍵字: {config.search_keyword}...", 40)
                search_success = await scraper.search()
                if not search_success:
                    callback.update("搜尋失敗", 0)
                    return False
                
                callback.update("搜尋成功，開始提取履歷資料...", 50)
                
                # 提取結果
                results = await scraper.extract_results()
                
                if results and len(results) > 0:
                    callback.update(f"爬蟲完成，共獲取 {len(results)} 份履歷！", 100)
                    return results
                else:
                    callback.update("未找到符合條件的履歷", 100)
                    return []
            else:
                callback.update("未設定搜尋關鍵字，搜尋全部結果", 40)
                search_success = await scraper.search()
                if not search_success:
                    callback.update("搜尋失敗", 0)
                    return False
                
                callback.update("搜尋成功，開始提取履歷資料...", 50)
                
                # 提取結果
                results = await scraper.extract_results()
                
                if results and len(results) > 0:
                    callback.update(f"爬蟲完成，共獲取 {len(results)} 份履歷！", 100)
                    return results
                else:
                    callback.update("未找到符合條件的履歷", 100)
                    return []
        except Exception as e:
            callback.update(f"爬蟲過程發生錯誤: {str(e)}", 0)
            return False
        finally:
            # 關閉瀏覽器
            await scraper.close()
    
    # 執行爬蟲
    with result_area:
        with st.spinner('爬蟲正在執行中，請耐心等待...'):
            results = asyncio.run(run_scraping())
            
            if results and isinstance(results, list):
                st.success(f"爬蟲完成，共獲取 {len(results)} 份履歷")
                st.info(f"結果已保存至目錄: {config.output_dir}")
                
                # 顯示履歷資料預覽
                if len(results) > 0:
                    st.subheader("履歷資料預覽")
                    df = pd.DataFrame(results)
                    st.dataframe(df)
                    
                    # 提供下載資料連結
                    excel_files = [f for f in os.listdir(config.output_dir) if f.endswith('.xlsx')]
                    if excel_files:
                        latest_excel = max(excel_files, key=lambda x: os.path.getmtime(os.path.join(config.output_dir, x)))
                        excel_path = os.path.join(config.output_dir, latest_excel)
                        
                        with open(excel_path, "rb") as file:
                            st.download_button(
                                label="下載Excel檔案",
                                data=file,
                                file_name=latest_excel,
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            )
            elif results is True:
                st.success("爬蟲流程已完成")
            else:
                st.error("爬蟲未能獲取有效結果")

# 顯示使用說明
with st.expander("使用說明"):
    st.markdown("""
    ### 如何使用此工具
    1. 輸入您的104企業會員帳號和密碼
    2. 輸入您想搜尋的關鍵詞（可選）
    3. 設定要爬取的頁數
    4. 點擊「開始爬取」按鈕
    5. 等待爬蟲完成，結果將自動保存並顯示在頁面上
    
    ### 注意事項
    - 爬蟲過程中瀏覽器視窗會自動打開，請勿關閉
    - 過程中可能需要輸入郵箱驗證碼，請留意終端機視窗提示
    - 結果會同時保存為Excel和JSON格式
    - 所有資料僅供研究學習使用
    """)
